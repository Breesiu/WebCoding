var headLineSelector =  $(".headLine");
var dataTableSelector =  $(".dataTable");
var selectBoxSelector =  $(".selectBox");
// var headLineSelector =  $(".headLine");
var headline='<div class="headLineElement">url</div><div class="headLineElement">source_name</div>' +
'<div class="headLineElement">title</div><div class="headLineElement">author</div><div class="headLineElement">publish_date</div>';

$(document).ready(function() {
    var page = 1;
    var pageMax = 1;
    $("input:button").click(function() {
        page = 1;
        $.get(`/process_get?title=${$("input:text").val()}`, function(data) {
            console.log(`/process_get?title=${$("input:text").val()}&page=${page}`);
            $(".headLine").empty();
            $(".dataTable").empty();
            $(".selectBox").empty();
            // $(".headLine").append("sda");
            $(".headLine").append(headline);
            console.log(data);
            pageMax = parseInt(data.length/10) + 1;

            console.log(pageMax);
            data = data.slice(0, 10);
            for (let list of data) {
                let table = '';
                Object.values(list).forEach(element => {
                    table += `<div class="element">${element}</div>`;
                });
                $(".dataTable").append(table);
            }
            $(".selectBox").append(`${page}/${pageMax}`);

        });
        // $(".selectBox").append('<p>sdadsas</p>');
        // $(".selectBox").append(`${page}/${pageMax}`);
        console.log(`${page}/${pageMax}`);
    });
    $(".arrows.prev").click(function() {
        if(page === 1)
            page = 1;
        else
            page -= 1;
        $.get(`/process_get?title=${$("input:text").val()}&page=${page}`, function(data) {
            console.log(`/process_get?title=${$("input:text").val()}&page=${page}`);
            $(".headLine").empty();
            $(".dataTable").empty();
            $(".selectBox").empty();
            // $(".headLine").append("sda");
            $(".headLine").append(headline);
            console.log(data);
            for (let list of data) {
                let table = '';
                Object.values(list).forEach(element => {
                    table += `<div class="element">${element}</div>`;
                });
                $(".dataTable").append(table);
            }
            $(".selectBox").append(`${page}/${pageMax}`);

        });
    });
    $(".arrows.next").click(function() {
        page += 1;
        $.get(`/process_get?title=${$("input:text").val()}&page=${page}`, function(data) {
            console.log(`/process_get?title=${$("input:text").val()}&page=${page}`);
            $(".headLine").empty();
            $(".dataTable").empty();
            $(".selectBox").empty();
            // $(".headLine").append("sda");
            $(".headLine").append(headline);
            console.log(data);
            for (let list of data) {
                let table = '';
                Object.values(list).forEach(element => {
                    table += `<div class="element">${element}</div>`;
                });
                $(".dataTable").append(table);
            }
            $(".selectBox").append(`${page}/${pageMax}`);

        });
    });
});